"use client"

import { useCallback, useEffect, useMemo, useState, type ElementType, type ReactNode } from "react"

import {
  AlertTriangle,
  BookOpen,
  Brain,
  CheckCircle2,
  Clock,
  Download,
  Info,
  ListChecks,
  Loader2,
  Printer,
  RefreshCw,
  Clock3,
  XCircle,
} from "lucide-react"
import {
  Area,
  AreaChart,
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { toast } from "sonner"

import {
  type ComparisonRow,
  type DailyBucket,
  type DisciplineStat,
  type HourBucket,
  type Insight,
  type MetricComparison,
  type TimeOfDayAnalysis,
  type TopicStat,
  buildDayBuckets,
  buildDayBucketsFromKeys,
  buildHeatmap,
  computeComparisons,
  computeDisciplineStats,
  computeEditalCoverage,
  computeFocusStatistics,
  computeFrequency,
  computeHoursOfDay,
  computeMonthlyReport,
  computePlanning,
  computePriorities,
  computeProductivity,
  computeQuestionStatistics,
  computeQuestionTrend,
  computeRevisionStatistics,
  computeSessionStatistics,
  computeStreaks,
  computeTimeCards,
  computeTimeOfDayAnalysis,
  computeTopicStats,
  computeWeeklyReport,
  dateKeyOf,
  formatBRDate,
  formatDurationRaw,
  generateInsights,
  keysBetween,
  mondayKeyOf,
  todayKey,
} from "@/application/study-analytics/engine/stats-engine"
import {
  type StatisticsCenterPayload,
  getStatisticsCenterAction,
} from "@/application/study-analytics/statistics-center.action"
import { Button } from "@/components/ui/button"

import {
  ClassificationChip,
  DeltaBadge,
  EmptyState,
  HeatmapCalendar,
  Metric,
  ProgressBar,
  SectionCard,
} from "./statistics-charts"

const TIMEZONE = "America/Sao_Paulo"

/**
 * Sinal de revisão vazio, usado quando a leitura de revisões falhou (Fase I.6,
 * M3). Não é "zero revisões" apresentado ao aluno: é a ausência de sinal para os
 * derivados (insights e atenção), que só falam de revisão quando há número > 0.
 * A seção de revisões, essa sim, mostra o erro explicitamente.
 */
const EMPTY_REVISION_STATISTICS: ReturnType<typeof computeRevisionStatistics> = {
  totalPending: 0,
  overdue: 0,
  dueToday: 0,
  upcoming: 0,
  completedLast30: 0,
  completionRate: null,
  byDiscipline: [],
}

/** Fase H: rótulo do card "Semana" pelo dia de início configurado (antes fixo "segunda"). */
const WEEK_START_LABEL = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"]

type RangeId = "all" | "7" | "30" | "90" | "365" | "custom"

const RANGES: { id: RangeId; label: string; days: number }[] = [
  { id: "all", label: "Tudo", days: 0 },
  { id: "7", label: "7 dias", days: 7 },
  { id: "30", label: "30 dias", days: 30 },
  { id: "90", label: "90 dias", days: 90 },
  { id: "365", label: "365 dias", days: 365 },
  { id: "custom", label: "Personalizado", days: 0 },
]

function rangeDays(range: RangeId, customStart: string, customEnd: string): number {
  if (range === "all") return 0
  if (range !== "custom") return RANGES.find((r) => r.id === range)?.days ?? 30
  const from = new Date(customStart + "T00:00:00")
  const to = new Date(customEnd + "T00:00:00")
  if (isNaN(from.getTime()) || isNaN(to.getTime()) || to < from) return 30
  return Math.round((to.getTime() - from.getTime()) / 86400000) + 1
}

type CmpKey = "minutes" | "questions" | "accuracy" | "focus" | "pages" | "sessions" | "days"

function metricCmpValue(m: MetricComparison | undefined, key: CmpKey): string {
  if (!m) return "—"
  const v = m.current
  if (v === null) return "—"
  if (key === "accuracy" || key === "focus") return `${Math.round(v)}%`
  if (key === "minutes") return formatDurationRaw(v)
  return String(Math.round(v))
}

function formatPlanningSubtitle(planning: {
  weeklyTargetMinutes: number
  weeklyTargetQuestions: number
  weeklyTargetDays: number
}): string {
  const questionTarget =
    planning.weeklyTargetQuestions > 0
      ? `${planning.weeklyTargetQuestions} questões`
      : "sem meta de questões"
  const dayTarget = planning.weeklyTargetDays > 0 ? ` · ${planning.weeklyTargetDays} dias` : ""
  return `Meta semanal: ${formatDurationRaw(planning.weeklyTargetMinutes)} · ${questionTarget}${dayTarget}`
}

function adherenceClass(adherencePct: number): string {
  if (adherencePct >= 100) return "text-emerald-600"
  if (adherencePct >= 50) return "text-amber-600"
  return "text-rose-600"
}

function daysSinceLastStudyLabel(days: number | null): string {
  if (days === null) return "nunca"
  if (days === 0) return "hoje"
  return `${days}d`
}

const INSIGHT_STYLES: Record<Insight["severity"], { icon: typeof Info; cls: string }> = {
  positive: { icon: CheckCircle2, cls: "border-emerald-500/30 bg-emerald-500/5" },
  info: { icon: Info, cls: "border-border bg-muted/40" },
  warning: { icon: AlertTriangle, cls: "border-amber-500/30 bg-amber-500/5" },
  danger: { icon: XCircle, cls: "border-rose-500/30 bg-rose-500/5" },
}

export interface StatisticsCenterInitialData {
  payload: StatisticsCenterPayload
  /** Momento (ISO) em que o servidor montou a página. */
  loadedAt: string
}

export function StatisticsCenterView({ initialData }: { initialData?: StatisticsCenterInitialData | null } = {}) {
  // ── Estado bruto ──────────────────────────────────────────────────────────
  // Fase F (performance): quando a página já trouxe os dados do servidor, a
  // tela nasce pronta — sem esperar o JavaScript carregar, hidratar e só
  // então disparar a Server Action (que ainda entrava na fila de actions).
  const [payload, setPayload] = useState<StatisticsCenterPayload | null>(initialData?.payload ?? null)
  const [loading, setLoading] = useState(!initialData)
  const [error, setError] = useState<string | null>(null)
  const [lastRefresh, setLastRefresh] = useState<Date | null>(() =>
    initialData ? new Date(initialData.loadedAt) : null,
  )

  // Fase F.2: se a página for re-renderizada no servidor (ex.: um estudo salvo
  // nesta aba — a Server Action revalida /estatisticas), os dados novos chegam
  // como um NOVO `initialData`; antes eram ignorados depois da montagem.
  // Padrão "valor da renderização anterior" do React (sem efeito).
  const [seenInitialData, setSeenInitialData] = useState(initialData)
  if (initialData && initialData !== seenInitialData) {
    setSeenInitialData(initialData)
    setPayload(initialData.payload)
    setError(null)
    setLastRefresh(new Date(initialData.loadedAt))
  }

  // ── Filtros ───────────────────────────────────────────────────────────────
  const [range, setRange] = useState<RangeId>("90")
  const [customStart, setCustomStart] = useState("")
  const [customEnd, setCustomEnd] = useState("")
  const [disciplineId, setDisciplineId] = useState<string>("all")
  const [studyType, setStudyType] = useState<string>("all")

  // Com dados do servidor, usa o mesmo "agora" do servidor para o HTML do
  // servidor e o do navegador serem idênticos (sem divergência de hidratação).
  const [now] = useState(() => (initialData ? new Date(initialData.loadedAt) : new Date()))

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true)
    const { data, error: err } = await getStatisticsCenterAction()
    if (err) {
      setError(err)
      if (!silent) toast.error(err)
    } else if (data) {
      setPayload(data)
      setError(null)
      setLastRefresh(new Date())
    }
    if (!silent) setLoading(false)
  }, [])

  const hasInitialData = Boolean(initialData)
  useEffect(() => {
    if (hasInitialData) return
    const timer = window.setTimeout(() => {
      void load()
    }, 0)
    return () => window.clearTimeout(timer)
  }, [load, hasInitialData])

  // ── Filtros derivados ─────────────────────────────────────────────────────
  const days = rangeDays(range, customStart, customEnd)
  const isAllRange = range === "all"
  const allSessionKeys = useMemo(() => {
    if (!isAllRange) return [] as string[]
    const keys = new Set<string>()
    for (const s of payload?.sessions ?? []) {
      const k = dateKeyOf(s.startedAt, TIMEZONE)
      if (k) keys.add(k)
    }
    for (const a of payload?.attempts ?? []) {
      if (!a.answeredAt) continue
      const k = dateKeyOf(a.answeredAt, TIMEZONE)
      if (k) keys.add(k)
    }
    return [...keys].sort()
  }, [payload, isAllRange])

  const rangeKeys = useMemo(() => {
    if (isAllRange) return allSessionKeys
    const today = todayKey(now, TIMEZONE)
    if (range === "custom" && customStart && customEnd) {
      return keysBetween(customStart, customEnd)
    }
    const keys: string[] = []
    for (let i = days - 1; i >= 0; i--) {
      const k = dateFromToday(today, -i)
      if (k) keys.push(k)
    }
    return keys
  }, [range, customStart, customEnd, days, now, isAllRange, allSessionKeys])

  const registry = useMemo(() => {
    const m = new Map<string, { id: string; name: string; area: string | null }>()
    ;(payload?.disciplines ?? []).forEach((d) => {
      if (d.id) m.set(d.id, d)
    })
    ;(payload?.sessions ?? []).forEach((s) => {
      if (s.disciplineId && !m.has(s.disciplineId)) {
        m.set(s.disciplineId, {
          id: s.disciplineId,
          name: s.disciplineName ?? s.disciplineId,
          area: s.disciplineArea,
        })
      }
    })
    return m
  }, [payload?.disciplines, payload?.sessions])

  const filteredSessions = useMemo(
    () =>
      filterSessions(
        payload?.sessions ?? [],
        rangeKeys,
        disciplineId,
        studyType,
        TIMEZONE,
        isAllRange,
      ),
    [payload, rangeKeys, disciplineId, studyType, isAllRange],
  )
  const filteredAttempts = useMemo(
    () => filterAttempts(payload?.attempts ?? [], rangeKeys, disciplineId, TIMEZONE, isAllRange),
    [payload, rangeKeys, disciplineId, isAllRange],
  )

  // ── Cálculos ──────────────────────────────────────────────────────────────
  const isCustomRange = range === "custom" && Boolean(customStart && customEnd)
  const buckets = useMemo(
    () =>
      isAllRange || isCustomRange
        ? buildDayBucketsFromKeys(filteredSessions, filteredAttempts, rangeKeys, TIMEZONE)
        : buildDayBuckets(
            filteredSessions,
            filteredAttempts,
            Math.max(1, rangeKeys.length),
            now,
            TIMEZONE,
          ),
    [filteredSessions, filteredAttempts, rangeKeys, now, isAllRange, isCustomRange],
  )
  const weekStartDay = payload?.weekStartDay ?? 0
  const timeCards = useMemo(
    () => computeTimeCards(buckets, now, TIMEZONE, weekStartDay),
    [buckets, now, weekStartDay],
  )
  const sessionStats = useMemo(() => computeSessionStatistics(filteredSessions), [filteredSessions])
  const questionStats = useMemo(
    () => computeQuestionStatistics(filteredSessions, filteredAttempts),
    [filteredSessions, filteredAttempts],
  )
  const focusStats = useMemo(() => computeFocusStatistics(filteredSessions), [filteredSessions])
  const streaks = useMemo(
    () =>
      computeStreaks(
        new Set(buckets.filter((b) => b.minutes > 0).map((b) => b.date)),
        now,
        TIMEZONE,
      ),
    [buckets, now],
  )
  const frequency = useMemo(() => computeFrequency(buckets, now, TIMEZONE, weekStartDay), [buckets, now, weekStartDay])
  // Fase I.6 (achado M3): `null` nas leituras de revisão quer dizer que a consulta
  // não respondeu. Nesse caso NÃO calculamos estatística de revisão: a seção
  // mostra erro em vez de "Sem revisões", e nenhum número de revisão é exibido.
  const revisionStats = useMemo(() => {
    if (!payload || payload.reviewItems === null || payload.reviewsCompletedLast30 === null) return null
    return computeRevisionStatistics(
      payload.reviewItems,
      payload.reviewsCompletedLast30,
      now,
      registry,
    )
  }, [payload, now, registry])
  // Sem dado de revisão não há sinal de revisão: mapa vazio significa "nenhuma
  // informação", e é assim que os derivados (atenção, insights) se comportam —
  // eles ficam calados em vez de afirmar que não há atraso.
  const revisionSignal = useMemo(
    () => revisionStats ?? EMPTY_REVISION_STATISTICS,
    [revisionStats],
  )
  const overdueByDiscipline = useMemo(() => {
    const m = new Map<string, number>()
    revisionStats?.byDiscipline.forEach((d) => m.set(d.disciplineId, d.overdue))
    return m
  }, [revisionStats])

  const disciplineStats = useMemo(
    () =>
      computeDisciplineStats(
        filteredSessions,
        filteredAttempts,
        registry,
        payload?.userDisciplines ?? [],
        overdueByDiscipline,
        timeCards.totalMinutes,
        now,
        TIMEZONE,
      ),
    [
      filteredSessions,
      filteredAttempts,
      registry,
      payload?.userDisciplines,
      overdueByDiscipline,
      timeCards.totalMinutes,
      now,
    ],
  )
  const topicStats = useMemo(
    () => computeTopicStats(filteredSessions, now, TIMEZONE),
    [filteredSessions, now],
  )
  const hoursOfDay = useMemo(
    () => computeHoursOfDay(filteredSessions, filteredAttempts, TIMEZONE),
    [filteredSessions, filteredAttempts],
  )
  const timeOfDayAnalysis = useMemo(
    () => computeTimeOfDayAnalysis(filteredSessions, filteredAttempts, TIMEZONE),
    [filteredSessions, filteredAttempts],
  )
  const comparisons = useMemo(
    () => computeComparisons(buckets, now, TIMEZONE, weekStartDay),
    [buckets, now, weekStartDay],
  )
  const planning = useMemo(
    () => computePlanning(payload?.activePlan ?? null, buckets, now, TIMEZONE, weekStartDay),
    [payload?.activePlan, buckets, now, weekStartDay],
  )
  const edital = useMemo(
    () => computeEditalCoverage(payload?.userDisciplines ?? [], disciplineStats, registry, now),
    [payload?.userDisciplines, disciplineStats, registry, now],
  )
  const productivity = useMemo(
    () =>
      computeProductivity(
        filteredSessions,
        questionStats,
        focusStats.averagePct,
        frequency.last7Days,
      ),
    [filteredSessions, questionStats, focusStats.averagePct, frequency.last7Days],
  )
  const questionTrend = useMemo(() => computeQuestionTrend(buckets), [buckets])
  const heatmap = useMemo(
    () => buildHeatmap(buckets, Math.min(rangeKeys.length, 365)),
    [buckets, rangeKeys],
  )
  const insights = useMemo(
    () =>
      generateInsights({
        hasPlan: planning.hasPlan,
        sessionsInRange: filteredSessions.length,
        hoursOfDay,
        timeOfDayAnalysis,
        focusPct: focusStats.averagePct,
        questionStats,
        streaks,
        comparisons,
        planning,
        revision: revisionSignal,
        disciplineStats,
        topicStats,
        timeCards,
        productivity,
        daysSinceLastStudy: frequency.daysSinceLastStudy,
        questionsPerDay:
          (isAllRange ? rangeKeys.length : days) > 0
            ? questionStats.total / (isAllRange ? rangeKeys.length : days)
            : 0,
      }),
    [
      filteredSessions.length,
      hoursOfDay,
      timeOfDayAnalysis,
      focusStats.averagePct,
      questionStats,
      streaks,
      comparisons,
      planning,
      revisionSignal,
      disciplineStats,
      topicStats,
      timeCards,
      productivity,
      frequency.daysSinceLastStudy,
      days,
      isAllRange,
      rangeKeys.length,
    ],
  )
  const priorities = useMemo(
    () => computePriorities(disciplineStats, revisionSignal),
    [disciplineStats, revisionSignal],
  )
  const weeklyReport = useMemo(() => computeWeeklyReport(buckets, now, TIMEZONE), [buckets, now])
  const monthlyReport = useMemo(() => computeMonthlyReport(buckets, now, TIMEZONE), [buckets, now])
  const effectiveDays = isAllRange ? rangeKeys.length : days
  const chartData = useMemo(
    () => buildChartData(buckets, effectiveDays, TIMEZONE),
    [buckets, effectiveDays],
  )

  // Opções de filtro (a partir dos dados totais, não filtrados)
  const allSessions = useMemo(() => payload?.sessions ?? [], [payload?.sessions])
  const disciplineOptions = useMemo(() => {
    const byId = new Map<string, string>()
    allSessions.forEach((s) => {
      if (s.disciplineId && !byId.has(s.disciplineId))
        byId.set(s.disciplineId, s.disciplineName ?? s.disciplineId)
    })
    payload?.disciplines.forEach((d) => {
      if (d.id) byId.set(d.id, d.name)
    })
    return [...byId.entries()]
      .map(([id, name]) => ({ id, name }))
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [allSessions, payload?.disciplines])
  const typeOptions = useMemo(() => {
    const names = new Set<string>()
    allSessions.forEach((s) => {
      if (s.studyType) names.add(s.studyType)
    })
    return [...names].sort()
  }, [allSessions])

  const hasAnyData = allSessions.length > 0 || filteredSessions.length > 0

  // ── Export ────────────────────────────────────────────────────────────────
  const exportCSV = () => {
    const lines: string[] = [
      "data;minutos;sessoes;questoes;acertos;erros;acuracia_pct;foco_pct;paginas;flashcards",
    ]
    buckets.forEach((b) => {
      lines.push(
        [
          b.date,
          Math.round(b.minutes),
          b.sessions,
          b.questions,
          b.correct,
          b.wrong,
          b.accuracy === null ? "" : Math.round(b.accuracy),
          b.focusAvg === null ? "" : Math.round(b.focusAvg),
          b.pages,
          b.flashcards,
        ].join(";"),
      )
    })
    lines.push("")
    lines.push(
      "disciplina;minutos;sessoes;questoes;acertos;acuracia_pct;tendencia;classificacao;score_atencao",
    )
    disciplineStats.forEach((d) => {
      lines.push(
        [
          d.name,
          Math.round(d.minutes),
          d.sessions,
          d.questions,
          d.correct,
          d.accuracy === null ? "" : Math.round(d.accuracy),
          d.trendDirection,
          d.classification,
          d.attentionScore,
        ].join(";"),
      )
    })
    const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `estatisticas-${todayKey(now, TIMEZONE)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (loading && !payload) {
    return (
      <div className="flex items-center justify-center p-20">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error && !payload) {
    return (
      <div className="rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground">
        <p className="font-semibold text-foreground mb-1">
          Não foi possível carregar suas estatísticas
        </p>
        <p className="mb-4">{error}</p>
        <Button onClick={() => load()}>Tentar novamente</Button>
      </div>
    )
  }

  return (
    <div className="space-y-4 pb-8 print:space-y-4">
      {/* ===================== FILTROS (toolbar) ===================== */}
      {/* Fase E — o título da página fica no cabeçalho fixo; aqui ficam só os
          filtros e as ações, numa única barra que quebra de forma previsível. */}
      <div className="flex flex-col gap-3 border-b border-border pb-4 2xl:flex-row 2xl:items-end 2xl:justify-between print:hidden">
        <div className="flex flex-wrap items-end gap-x-4 gap-y-3">
          <div className="space-y-1">
            <p id="stats-range-label" className="text-xs text-muted-foreground">Período</p>
            <div
              role="group"
              aria-labelledby="stats-range-label"
              className="inline-flex items-center rounded-md bg-muted p-0.5"
            >
              {RANGES.map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setRange(r.id)}
                  aria-pressed={range === r.id}
                  className={`whitespace-nowrap rounded-[5px] px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                    range === r.id
                      ? "bg-card text-foreground shadow-xs"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {range === "custom" && (
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={customStart}
                max={customEnd || undefined}
                aria-label="Data inicial"
                onChange={(e) => setCustomStart(e.target.value)}
                className="h-8 rounded-md border border-input bg-card px-2 text-xs text-foreground"
              />
              <input
                type="date"
                value={customEnd}
                min={customStart || undefined}
                aria-label="Data final"
                onChange={(e) => setCustomEnd(e.target.value)}
                className="h-8 rounded-md border border-input bg-card px-2 text-xs text-foreground"
              />
            </div>
          )}

          <label className="space-y-1">
            <span className="block text-xs text-muted-foreground">Disciplina</span>
            <select
              value={disciplineId}
              onChange={(e) => setDisciplineId(e.target.value)}
              className="h-8 w-48 rounded-md border border-input bg-card px-2 text-xs text-foreground"
            >
              <option value="all">Todas</option>
              {disciplineOptions.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </label>

          <label className="space-y-1">
            <span className="block text-xs text-muted-foreground">Tipo de estudo</span>
            <select
              value={studyType}
              onChange={(e) => setStudyType(e.target.value)}
              className="h-8 w-40 rounded-md border border-input bg-card px-2 text-xs text-foreground"
            >
              <option value="all">Todos</option>
              {typeOptions.map((t) => (
                <option key={t} value={t}>
                  {typeLabel(t)}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <p className="mr-1 text-xs text-muted-foreground tabular-nums">
            {filteredSessions.length} {filteredSessions.length === 1 ? "sessão" : "sessões"} no período
            {lastRefresh && (
              <>
                {" "}
                · atualizado às{" "}
                {lastRefresh.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: TIMEZONE })}
              </>
            )}
          </p>
          <Button variant="outline" size="sm" onClick={() => load(true)}>
            <RefreshCw aria-hidden className="h-3.5 w-3.5" /> Atualizar
          </Button>
          <Button variant="outline" size="sm" onClick={exportCSV}>
            <Download aria-hidden className="h-3.5 w-3.5" /> CSV
          </Button>
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer aria-hidden className="h-3.5 w-3.5" /> PDF
          </Button>
        </div>
      </div>

      {!hasAnyData && (
        <div className="rounded-lg border border-dashed border-border p-6 text-center">
          <p className="text-sm font-medium text-foreground mb-1">
            Nenhum estudo registrado no período
          </p>
          <p className="text-[13px] text-muted-foreground mb-4">
            Registre uma sessão de estudo para começar a ver suas estatísticas reais.
          </p>
          <Button asChild size="sm">
            <a href="/dashboard/history">Registrar sessão</a>
          </Button>
        </div>
      )}

      {/* ===================== CARDS DE TEMPO ===================== */}
      <SectionCard
        title="Tempo de estudo"
        subtitle={`Hoje, semana, mês e janelas no período selecionado (fuso ${TIMEZONE.replace("_", " ")})`}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          <Metric
            label="Hoje"
            value={formatDurationRaw(timeCards.todayMinutes)}
            sub="sessões de hoje"
            accent
          />
          <Metric
            label="Semana"
            value={formatDurationRaw(timeCards.weekMinutes)}
            sub={`${WEEK_START_LABEL[weekStartDay] ?? "domingo"} → hoje`}
            accent
          />
          <Metric
            label="Mês"
            value={formatDurationRaw(timeCards.monthMinutes)}
            sub="dia 1 → hoje"
            accent
          />
          <Metric
            label="Últimos 30d"
            value={formatDurationRaw(timeCards.last30Minutes)}
            sub="janela móvel"
          />
          <Metric
            label="Últimos 90d"
            value={formatDurationRaw(timeCards.last90Minutes)}
            sub="janela móvel"
          />
          <Metric
            label="Total no período"
            value={formatDurationRaw(timeCards.totalMinutes)}
            sub={`${timeCards.studiedDayCount} dias estudados`}
            accent
          />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Metric
            label="Média por dia estudado"
            value={formatDurationRaw(timeCards.avgPerStudiedDay)}
            sub="minutos ÷ dias com sessão"
          />
          <Metric
            label="Média por dia do período"
            value={formatDurationRaw(timeCards.avgPerPeriodDay)}
            sub="minutos ÷ dias do período"
          />
          <Metric
            label="Maior dia"
            value={timeCards.bestDay ? formatDurationRaw(timeCards.bestDay.minutes) : "—"}
            sub={timeCards.bestDay ? formatBRDate(timeCards.bestDay.date) : "sem estudo"}
          />
          <Metric
            label="Menor dia"
            value={timeCards.worstDay ? formatDurationRaw(timeCards.worstDay.minutes) : "—"}
            sub={timeCards.worstDay ? formatBRDate(timeCards.worstDay.date) : "—"}
          />
        </div>
        {timeCards.totalMinutes === 0 && filteredSessions.length > 0 && (
          <p className="text-[11px] text-muted-foreground">
            Há sessões registradas, mas nenhuma com duração válida no período.
          </p>
        )}
      </SectionCard>

      {/* ===================== MÉTRICAS BASE ===================== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <SectionCard title="Sessões" subtitle="Concluídas e interrompidas">
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Total</span>
              <span className="font-semibold">{sessionStats.total}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Média de duração</span>
              <span className="font-semibold">{formatDurationRaw(sessionStats.averageMinutes)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Mais longa</span>
              <span className="font-semibold">{formatDurationRaw(sessionStats.longestMinutes)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Concluídas</span>
              <span className="font-semibold text-emerald-600">{sessionStats.completed}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Interrompidas</span>
              <span className="font-semibold text-amber-600">{sessionStats.interrupted}</span>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Desempenho" subtitle={`${questionStats.total} questões no período`}>
          <div className="flex items-center gap-4">
            <Donut value={questionStats.accuracy} size={84} />
            <div className="space-y-1 text-sm flex-1">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Acertos</span>
                <span className="font-semibold text-emerald-600">{questionStats.correct}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Erros</span>
                <span className="font-semibold text-rose-600">{questionStats.wrong}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Acurácia</span>
                <span className="font-semibold">
                  {questionStats.accuracy === null ? "—" : `${Math.round(questionStats.accuracy)}%`}
                </span>
              </div>
            </div>
          </div>
          {questionStats.total === 0 && (
            <p className="text-[11px] text-muted-foreground">
              Acurácia aparece quando houver questões respondidas (manual ou pela plataforma).
            </p>
          )}
        </SectionCard>

        <SectionCard title="Qualidade" subtitle="Foco e pausas">
          <div className="text-sm">
            <div className="font-semibold text-3xl mb-1">
              {focusStats.average === null ? "—" : `${Math.round(focusStats.average)}%`}
            </div>
            <p className="text-xs text-muted-foreground mb-3">foco médio das sessões</p>
            <ProgressBar pct={focusStats.average ?? 0} barClass={focusBarCls(focusStats.average)} />
            <div className="flex justify-between mt-2 text-xs text-muted-foreground">
              <span>Ativo {formatDurationRaw(focusStats.totalActiveMinutes)}</span>
              <span>Pausa {formatDurationRaw(focusStats.totalPausedMinutes)}</span>
            </div>
            <div className="flex justify-between mt-1 text-xs text-muted-foreground">
              <span>
                {focusStats.activeRatio !== null
                  ? `${Math.round(focusStats.activeRatio * 100)}% do tempo ativo`
                  : ""}
              </span>
              <span>
                {focusStats.best !== null ? `melhor ${Math.round(focusStats.best)}%` : ""}
              </span>
            </div>
          </div>
        </SectionCard>

        <SectionCard title="Constância" subtitle="Sequência e frequência">
          <div className="text-sm space-y-1.5">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Sequência atual</span>
              <span className="font-semibold text-lg">
                {streaks.current} {streaks.current === 1 ? "dia" : "dias"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Maior sequência</span>
              <span className="font-semibold">{streaks.longest} dias</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Últimos 7 dias</span>
              <span className="font-semibold">{frequency.last7Days} de 7</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Últimos 30 dias</span>
              <span className="font-semibold">{frequency.last30Days} de 30</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Média semanal</span>
              <span className="font-semibold">{frequency.weeklyAvgDays.toFixed(1)} dias</span>
            </div>
            {frequency.daysSinceLastStudy !== null && frequency.daysSinceLastStudy > 0 && (
              <p className="text-[11px] text-amber-600 font-semibold">
                {frequency.daysSinceLastStudy} dias sem estudar
                {streaks.current === 0 ? " — quebre o ciclo hoje" : ""}
              </p>
            )}
            {streaks.current >= 3 && (
              <p className="text-[11px] text-emerald-600 font-semibold">
                Sequência de {streaks.current} dias!
              </p>
            )}
          </div>
        </SectionCard>
      </div>

      {/* ===================== EVOLUÇÃO ===================== */}
      <EvolutionChart
        data={chartData}
        rangeDays={effectiveDays}
        empty={filteredSessions.length === 0}
      />

      {/* ===================== HEATMAP ===================== */}
      <SectionCard
        title="Calendário de atividade"
        subtitle="Intensidade de estudo por dia (nível por percentil)"
        action={<HeatmapLegendNote />}
      >
        {heatmap.length > 0 ? (
          <HeatmapCalendar cells={heatmap} now={now} timezone={TIMEZONE} />
        ) : (
          <EmptyState title="Sem dados" message="Sem dados no período selecionado." />
        )}
      </SectionCard>

      {/* ===================== DISCIPLINAS ===================== */}
      <DisciplinasSection
        stats={disciplineStats}
        totalMinutes={timeCards.totalMinutes}
        empty={filteredSessions.length === 0}
      />

      {/* ===================== TÓPICOS ===================== */}
      <SectionCard
        title="Matérias (tópicos)"
        subtitle="Agrupados por tema registrado nas sessões — classificação pela mesma regra das disciplinas"
      >
        {topicStats.length === 0 ? (
          <EmptyState title="Sem tópicos" message="Registre tópicos nas sessões (ex.: “Controle de Constitucionalidade”) para ver o desempenho por assunto." />
        ) : (
          <div className="max-h-96 overflow-auto">
            <table className="w-full text-xs min-w-[520px]">
              <thead>
                <tr className="type-label border-b">
                  <th className="py-2.5 px-3 text-left font-semibold">Tópico</th>
                  <th className="py-2.5 px-3 text-left font-semibold">Disciplina</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Tempo</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Questões</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Acurácia</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {topicStats.slice(0, 50).map((t) => (
                  <tr
                    key={`${t.disciplineId}-${t.topicName}`}
                    className="border-t border-border/40 hover:bg-muted/20 transition-colors"
                  >
                    <td className="py-2.5 px-3 font-semibold">{t.topicName}</td>
                    <td className="py-2.5 px-3 text-muted-foreground">{t.disciplineName}</td>
                    <td className="py-2.5 px-3 text-right tabular-nums">
                      {formatDurationRaw(t.minutes)}
                    </td>
                    <td className="py-2.5 px-3 text-right">{t.questions}</td>
                    <td className="py-2.5 px-3 text-right font-semibold">
                      {t.accuracy === null ? "—" : `${Math.round(t.accuracy)}%`}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <ClassificationChip classification={t.classification} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>

      {/* ===================== QUESTÕES ===================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <SectionCard
          title="Questões ao longo do tempo"
          subtitle="Volume diário e acurácia em linha"
        >
          {questionTrend.length === 0 ? (
            <EmptyState title="Sem questões" message="Sem questões registradas no período." />
          ) : (
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={questionTrend}
                  margin={{ top: 5, right: 10, bottom: 5, left: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="date"
                    tickFormatter={shortDate}
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                    tickLine={false}
                    axisLine={false}
                    minTickGap={24}
                  />
                  <YAxis
                    yAxisId="q"
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                  />
                  <YAxis
                    yAxisId="a"
                    orientation="right"
                    domain={[0, 100]}
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                    tickLine={false}
                    axisLine={false}
                    width={30}
                  />
                  <Tooltip content={<QTooltip />} />
                  <Legend
                    wrapperStyle={{ fontSize: "11px" }}
                    formatter={(v) => (
                      <span style={{ color: "hsl(var(--muted-foreground))" }}>{v}</span>
                    )}
                  />
                  <Bar
                    yAxisId="q"
                    dataKey="questions"
                    name="Questões"
                    fill="hsl(var(--primary))"
                    radius={[3, 3, 0, 0]}
                    barSize={Math.max(2, Math.min(10, 360 / questionTrend.length))}
                  />
                  <Line
                    yAxisId="a"
                    type="monotone"
                    dataKey="accuracy"
                    name="Acurácia %"
                    stroke="#22c55e"
                    strokeWidth={2}
                    dot={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}
        </SectionCard>

        <SectionCard
          title="Mapa de erros"
          subtitle="Onde os erros se concentram (rever antes de avançar)"
        >
          <ErrorMap
            disciplineStats={disciplineStats}
            topicStats={topicStats.filter((t) => t.wrong > 0)}
            empty={questionStats.total === 0}
          />
        </SectionCard>
      </div>

      {/* ===================== PRODUTIVIDADE ===================== */}
      <SectionCard
        title="Produtividade"
        subtitle="Índice 0-100 com fórmula documentada abaixo"
        action={
          productivity.score !== null ? (
            <span className="text-3xl font-semibold text-primary tabular-nums">
              {productivity.score}
            </span>
          ) : null
        }
      >
        {productivity.score === null ? (
          <div>
            <EmptyState title="Produtividade indisponível" message="Complete ao menos 3 sessões no período para calcular o índice de produtividade — a fórmula soma tempo ativo (40%), acurácia (30%), foco (20%) e constância (10%); com menos de 5 questões a acurácia sai e os pesos passam a 40%, 45% e 15%." />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Fase H: pesos e valores conforme o cálculo realmente feito. */}
            <Metric
              label={`Tempo ativo (${productivity.weights?.activeRatio ?? 40}%)`}
              value={`${productivity.breakdown.activeRatioScore}%`}
              sub="minutos ativos ÷ duração total"
            />
            <Metric
              label={
                productivity.weights?.accuracy
                  ? `Acurácia (${productivity.weights.accuracy}%)`
                  : "Acurácia (fora do índice)"
              }
              value={
                productivity.weights?.hasAccuracy === false
                  ? "—"
                  : `${productivity.breakdown.accuracyScore}%`
              }
              sub={
                productivity.weights?.hasAccuracy === false
                  ? "menos de 5 questões no período"
                  : "com ≥5 questões no período"
              }
            />
            <Metric
              label={`Foco (${productivity.weights?.focus ?? 20}%)`}
              value={
                productivity.weights?.hasFocus === false ? "—" : `${productivity.breakdown.focusScore}%`
              }
              sub={
                productivity.weights?.hasFocus === false
                  ? "sem foco registrado (conta como 0 no índice)"
                  : "foco médio das sessões"
              }
            />
            <Metric
              label={`Constância (${productivity.weights?.consistency ?? 10}%)`}
              value={`${productivity.breakdown.consistencyScore}%`}
              sub="dias estudados nos últimos 7"
            />
          </div>
        )}
      </SectionCard>

      {/* ===================== ANÁLISE INTELIGENTE ===================== */}
      <SectionCard
        title="Observações sobre seus dados"
        subtitle="Padrões calculados a partir dos seus registros de estudo"
      >
        <BestTimeOfDaySection analysis={timeOfDayAnalysis} />
        {insights.length === 0 ? (
          <EmptyState title="Ainda sem observações" message="Registre mais sessões para que padrões possam ser calculados." />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {insights.map((ins) => {
              const style = INSIGHT_STYLES[ins.severity]
              const Icon = style.icon
              return (
                <div key={ins.id} className={`rounded-xl border p-3.5 flex gap-3 ${style.cls}`}>
                  <Icon className="h-4 w-4 mt-0.5 shrink-0 text-foreground/70" />
                  <div>
                    <p className="text-xs font-semibold text-foreground">{ins.title}</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">
                      {ins.message}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </SectionCard>

      {/* ===================== PRIORIDADES ===================== */}
      <SectionCard
        title="Prioridades de estudo"
        subtitle="Score de atenção 0-100: desempenho 30% · erros 15% · abandono 20% · revisão atrasada 15% · cobertura 10% · tendência 10%"
        action={<ListChecks className="h-4 w-4 text-primary" />}
      >
        {priorities.length === 0 ? (
          <EmptyState title="Sem prioridades" message="Sem disciplinas estudadas no período." />
        ) : (
          <div className="space-y-3">
            {priorities.map((p, i) => (
              <div
                key={p.disciplineId}
                className="flex items-start gap-3 rounded-lg border bg-card p-3"
              >
                <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-semibold flex items-center justify-center shrink-0">
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <p className="text-xs font-semibold">{p.name}</p>
                    <span className="text-xs font-semibold tabular-nums text-primary">
                      {p.score}
                      <span className="text-muted-foreground font-semibold">/100</span>
                    </span>
                  </div>
                  {p.reasons.length > 0 && (
                    <p className="text-[11px] text-muted-foreground mt-0.5">
                      {p.reasons.join(" · ")}
                    </p>
                  )}
                  <p className="text-[11px] text-foreground/80 mt-1 font-medium">{p.action}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      {/* ===================== REVISÕES ===================== */}
      <RevisionSection revision={revisionStats} />

      {/* ===================== PLANEJADO X REALIZADO ===================== */}
      <SectionCard
        title="Planejado × Realizado"
        subtitle={
          planning.hasPlan
            ? formatPlanningSubtitle(planning)
            : "Sem plano ativo — crie um plano no concurso para acompanhar aqui"
        }
        action={
          planning.hasPlan && planning.adherencePct !== null ? (
            <span className={`text-xs font-semibold ${adherenceClass(planning.adherencePct)}`}>
              {Math.round(planning.adherencePct)}% da meta semanal
            </span>
          ) : null
        }
      >
        {!planning.hasPlan ? (
          <EmptyState title="Sem plano ativo" message="Quando houver um plano ativo, o gráfico mostra o planejado por dia da semana (pela grade do plano) contra o realizado." />
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Metric
                label="Meta semanal"
                value={formatDurationRaw(planning.weeklyTargetMinutes)}
                sub="minutos planejados"
              />
              <Metric
                label="Realizado na semana"
                value={formatDurationRaw(planning.actualWeekMinutes)}
                sub={`${planning.actualWeekDays} dias`}
                accent
              />
              <Metric
                label="Aderência"
                value={
                  planning.adherencePct === null ? "—" : `${Math.round(planning.adherencePct)}%`
                }
                sub="realizado ÷ meta semanal"
              />
              <Metric
                label="Questões da semana"
                value={String(planning.actualWeekQuestions)}
                sub={
                  planning.weeklyTargetQuestions > 0
                    ? `meta ${planning.weeklyTargetQuestions}`
                    : "sem meta"
                }
              />
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={planning.series}
                  margin={{ top: 5, right: 10, bottom: 5, left: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="date"
                    tickFormatter={shortDate}
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                    tickLine={false}
                    axisLine={false}
                    minTickGap={32}
                  />
                  <YAxis
                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                    tickLine={false}
                    axisLine={false}
                    width={40}
                    tickFormatter={(v: number) => formatDurationRaw(v)}
                  />
                  <Tooltip content={<PlanTooltip />} />
                  <Legend
                    wrapperStyle={{ fontSize: "11px" }}
                    formatter={(v) => (
                      <span style={{ color: "hsl(var(--muted-foreground))" }}>{v}</span>
                    )}
                  />
                  <Bar
                    dataKey="actualMinutes"
                    name="Realizado"
                    fill="hsl(var(--primary))"
                    radius={[3, 3, 0, 0]}
                  />
                  <Line
                    type="stepAfter"
                    dataKey="plannedMinutes"
                    name="Planejado"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    dot={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
      </SectionCard>

      {/* ===================== EDITAL ===================== */}
      <SectionCard
        title="Progresso no edital"
        subtitle="Status das disciplinas do seu concurso e cobertura geral"
        action={
          <div className="flex items-center gap-2">
            <span className="text-2xl font-semibold text-primary tabular-nums">
              {Math.round(edital.percentage)}%
            </span>
            <div className="w-28">
              <ProgressBar pct={edital.percentage} />
            </div>
          </div>
        }
      >
        {edital.total === 0 ? (
          <EmptyState title="Sem edital" message="Adicione um concurso (edital) para acompanhar a cobertura por disciplina." />
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <Metric label="Total" value={edital.total} sub="disciplinas no edital" />
              <Metric label="Concluídas" value={edital.completed} sub="status CONCLUÍDA" />
              <Metric label="Em estudo" value={edital.studying} sub="status EM_ESTUDO" />
              <Metric label="Não iniciadas" value={edital.notStarted} sub="status NOT_STARTED" />
            </div>
            <div className="max-h-72 overflow-auto">
              <table className="w-full text-xs min-w-[480px]">
                <thead>
                  <tr className="type-label border-b">
                    <th className="py-2.5 px-3 text-left font-semibold">Disciplina</th>
                    <th className="py-2.5 px-3 text-left font-semibold">Área</th>
                    <th className="py-2.5 px-3 text-right font-semibold">Estudado</th>
                    <th className="py-2.5 px-3 text-right font-semibold">Última sessão</th>
                    <th className="py-2.5 px-3 text-right font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {edital.byDiscipline.map((d) => (
                    <tr key={d.disciplineId} className="border-t border-border/40 hover:bg-muted/20 transition-colors">
                      <td className="py-2.5 px-3 font-semibold">{d.name}</td>
                      <td className="py-2.5 px-3 text-muted-foreground">{d.area ?? "—"}</td>
                      <td className="py-2.5 px-3 text-right tabular-nums">
                        {formatDurationRaw(d.studiedMinutes)}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {daysSinceLastStudyLabel(d.daysSinceLastStudy)}
                      </td>
                      <td className="py-2.5 px-3 text-right">{statusLabel(d.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </SectionCard>

      {/* ===================== EU VS EU ===================== */}
      <SectionCard
        title="Eu × Eu"
        subtitle="Comparações do período atual contra seus próprios períodos anteriores"
      >
        <ComparisonsTable rows={comparisons} />
      </SectionCard>

      {/* ===================== HORÁRIOS ===================== */}
      <SectionCard
        title="Períodos do dia"
        subtitle="Manhã, tarde, noite e madrugada — por tempo e desempenho registrado"
      >
        <HoursSection hours={hoursOfDay} empty={filteredSessions.length === 0} />
      </SectionCard>

      {/* ===================== RESUMOS ===================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <SectionCard title="Resumo semanal" subtitle="Últimos 7 dias vs os 7 anteriores">
          <ReportTable rows={weeklyReport} />
        </SectionCard>
        <SectionCard title="Resumo mensal" subtitle="Mês corrido vs mês anterior completo">
          <ReportTable rows={monthlyReport} />
        </SectionCard>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════════════

function dateFromToday(today: string, offsetDays: number): string | null {
  const d = new Date(today + "T00:00:00Z")
  d.setUTCDate(d.getUTCDate() + offsetDays)
  return d.toISOString().slice(0, 10)
}

function filterSessions(
  sessions: StatisticsCenterPayload["sessions"],
  rangeKeys: string[],
  disciplineId: string,
  studyType: string,
  timezone: string,
  isAllRange: boolean,
) {
  if (isAllRange) {
    return sessions.filter((s) => {
      if (disciplineId !== "all" && s.disciplineId !== disciplineId) return false
      if (studyType !== "all" && s.studyType !== studyType) return false
      return true
    })
  }
  const min = rangeKeys[0]
  const max = rangeKeys[rangeKeys.length - 1]
  return sessions.filter((s) => {
    const k = dateKeyOf(s.startedAt, timezone)
    if (!k || !min || !max) return false
    if (k < min || k > max) return false
    if (disciplineId !== "all" && s.disciplineId !== disciplineId) return false
    if (studyType !== "all" && s.studyType !== studyType) return false
    return true
  })
}

function filterAttempts(
  attempts: StatisticsCenterPayload["attempts"],
  rangeKeys: string[],
  disciplineId: string,
  timezone: string,
  isAllRange: boolean,
) {
  if (isAllRange) {
    return attempts.filter((a) => {
      if (disciplineId !== "all" && a.disciplineId !== disciplineId && a.disciplineId !== null)
        return false
      return true
    })
  }
  const min = rangeKeys[0]
  const max = rangeKeys[rangeKeys.length - 1]
  return attempts.filter((a) => {
    if (disciplineId !== "all" && a.disciplineId !== disciplineId && a.disciplineId !== null)
      return false
    if (!a.answeredAt) return true
    const k = dateKeyOf(a.answeredAt, timezone)
    if (!k || !min || !max) return false
    return k >= min && k <= max
  })
}

function buildChartData(buckets: DailyBucket[], rangeDays: number, _timezone: string) {
  if (rangeDays > 90) {
    const groups = new Map<string, DailyBucket>()
    buckets.forEach((b) => {
      const monday = mondayKeyOf(b.date)
      if (!monday) return
      let g = groups.get(monday)
      if (!g) {
        g = { ...b }
        groups.set(monday, g)
      } else {
        g.minutes += b.minutes
        g.sessions += b.sessions
        g.questions += b.questions
        g.correct += b.correct
        g.wrong += b.wrong
        g.pages += b.pages
        g.focusSum += b.focusSum
        g.focusCount += b.focusCount
      }
    })
    return [...groups.entries()].map(([monday, g]) => ({
      label: shortDate(monday),
      date: monday,
      minutos: Math.round(g.minutes),
      questoes: g.questions,
      acuracia: g.questions > 0 ? Math.round((g.correct / g.questions) * 100) : null,
      foco: g.focusCount > 0 ? Math.round(g.focusSum / g.focusCount) : null,
      paginas: g.pages,
      sessoes: g.sessions,
    }))
  }
  return buckets.map((b) => ({
    label: shortDate(b.date),
    date: b.date,
    minutos: Math.round(b.minutes),
    questoes: b.questions,
    acuracia: b.accuracy === null ? null : Math.round(b.accuracy),
    foco: b.focusAvg === null ? null : Math.round(b.focusAvg),
    paginas: b.pages,
    sessoes: b.sessions,
  }))
}

function shortDate(key: string): string {
  const [, m, d] = key.split("-")
  return `${d}/${m}`
}

function typeLabel(t: string): string {
  const map: Record<string, string> = {
    TEORIA: "Teoria",
    QUESTOES: "Questões",
    REVISAO: "Revisão",
    RESUMO: "Resumo",
    MAPA_MENTAL: "Mapa mental",
    FLASHCARDS: "Flashcards",
    VIDEOAULA: "Videoaula",
    AUDIO: "Áudio",
    AULA_VIVO: "Aula ao vivo",
    LEITURA: "Leitura",
    LEI_SECA: "Lei seca",
    JURISPRUDENCIA: "Jurisprudência",
    INFORMATIVOS: "Informativo",
    DOUTRINA: "Doutrina",
    SIMULADO: "Simulado",
    MONITORIA: "Monitoria",
    ESTUDO_IA: "Estudo com IA",
    DISCUSSAO: "Discussão",
    OUTRO: "Outro",
  }
  return map[t] ?? t
}

function statusLabel(status: string): ReactNode {
  const map: Record<string, { label: string; icon: ElementType; className: string }> = {
    CONCLUIDA: { label: "Concluída", icon: CheckCircle2, className: "text-emerald-600 dark:text-emerald-400" },
    COMPLETED: { label: "Concluída", icon: CheckCircle2, className: "text-emerald-600 dark:text-emerald-400" },
    CONCLUÍDA: { label: "Concluída", icon: CheckCircle2, className: "text-emerald-600 dark:text-emerald-400" },
    EM_ESTUDO: { label: "Em estudo", icon: BookOpen, className: "text-primary" },
    STUDYING: { label: "Em estudo", icon: BookOpen, className: "text-primary" },
    EM_REVISAO: { label: "Em revisão", icon: RefreshCw, className: "text-amber-600 dark:text-amber-400" },
    REVISING: { label: "Em revisão", icon: RefreshCw, className: "text-amber-600 dark:text-amber-400" },
    NOT_STARTED: { label: "Não iniciada", icon: Clock, className: "text-muted-foreground" },
    NOT_STARTED_: { label: "Não iniciada", icon: Clock, className: "text-muted-foreground" },
  }
  const entry = map[status]
  if (!entry) return status
  const Icon = entry.icon
  return (
    <span className={`inline-flex items-center gap-1 justify-end ${entry.className}`}>
      <Icon className="h-3.5 w-3.5 shrink-0" />
      {entry.label}
    </span>
  )
}

function focusBarCls(pct: number | null): string {
  if (pct === null) return "bg-muted"
  if (pct >= 75) return "bg-emerald-500"
  if (pct >= 50) return "bg-amber-500"
  return "bg-rose-500"
}

function Donut({ value, size }: { value: number | null; size: number }) {
  const v = value === null ? 0 : Math.max(0, Math.min(100, Math.round(value)))
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
        <circle
          cx="18"
          cy="18"
          r="15.9"
          fill="none"
          stroke="currentColor"
          strokeWidth="3.8"
          className="text-muted/40"
        />
        <circle
          cx="18"
          cy="18"
          r="15.9"
          fill="none"
          stroke="hsl(var(--primary))"
          strokeWidth="3.8"
          strokeLinecap="round"
          strokeDasharray={`${v}, 100`}
          className={value === null ? "opacity-30" : ""}
        />
      </svg>
      <div
        className="absolute inset-0 flex items-center justify-center font-semibold tabular-nums"
        style={{ fontSize: size / 4.6 }}
      >
        {value === null ? "—" : `${v}%`}
      </div>
    </div>
  )
}

function HeatmapLegendNote() {
  return (
    <span className="text-[10px] text-muted-foreground">
      níveis por percentil de minutos por dia
    </span>
  )
}

function formatEvolutionValue(metric: string, value: number): string {
  if (metric === "minutos") return formatDurationRaw(value)
  if (metric === "acuracia" || metric === "foco") return `${Math.round(value)}%`
  return String(Math.round(value))
}

// ─── Evolução ───────────────────────────────────────────────────────────────

const EVO_METRICS = [
  { id: "minutos", label: "Tempo" },
  { id: "questoes", label: "Questões" },
  { id: "acuracia", label: "Acurácia" },
  { id: "foco", label: "Foco" },
  { id: "paginas", label: "Páginas" },
  { id: "sessoes", label: "Sessões" },
]

type EvolutionDataPoint = {
  label: string
  date: string
  minutos: number
  questoes: number
  acuracia: number | null
  foco: number | null
  paginas: number
  sessoes: number
}

type ChartTooltipProps = {
  active?: boolean
  label?: string
  payload?: {
    value?: number
    payload?: EvolutionDataPoint & {
      actualMinutes?: number
      plannedMinutes?: number
      actualSessions?: number
    }
  }[]
}

function EvolutionChart({
  data,
  rangeDays,
  empty,
}: {
  data: EvolutionDataPoint[]
  rangeDays: number
  empty: boolean
}) {
  const [metric, setMetric] = useState("minutos")
  const lineBased = metric === "acuracia" || metric === "foco"
  let color = "hsl(var(--primary))"
  if (metric === "acuracia") color = "#22c55e"
  else if (metric === "foco") color = "#8b5cf6"

  const fmt = (value: number) => formatEvolutionValue(metric, value)

  return (
    <SectionCard
      title="Evolução"
      subtitle={rangeDays > 90 ? "Agregado por semana" : "Por dia"}
      action={
        <div className="flex gap-1 bg-muted/50 p-1 rounded-lg flex-wrap print:hidden">
          {EVO_METRICS.map((m) => (
            <button
              key={m.id}
              onClick={() => setMetric(m.id)}
              className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-all ${
                metric === m.id
                  ? "bg-background text-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      }
    >
      {empty || data.length === 0 ? (
        <EmptyState title="Sem sessões" message="Sem sessões no período selecionado." />
      ) : (
        <div className="h-60">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
              <defs>
                <linearGradient id="evoFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={color} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis
                dataKey="label"
                tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                tickLine={false}
                axisLine={false}
                minTickGap={24}
              />
              <YAxis
                tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                tickLine={false}
                axisLine={false}
                width={38}
                tickFormatter={fmt}
              />
              <Tooltip content={<EvoTooltip metric={metric} />} />
              {lineBased ? (
                <Line
                  type="monotone"
                  dataKey={metric}
                  stroke={color}
                  strokeWidth={2.5}
                  dot={false}
                  activeDot={{ r: 5 }}
                />
              ) : (
                <Area
                  type="monotone"
                  dataKey={metric}
                  stroke={color}
                  strokeWidth={2.5}
                  fill="url(#evoFill)"
                  dot={false}
                />
              )}
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </SectionCard>
  )
}

function EvoTooltip({ active, payload, label, metric }: ChartTooltipProps & { metric: string }) {
  if (!active || !payload?.length) return null
  const v = payload[0]?.value
  const full = payload[0]?.payload
  return (
    <div className="rounded-lg border bg-card p-3 shadow-lg text-xs space-y-1">
      <p className="font-semibold mb-1">{label}</p>
      <p>
        <span className="text-muted-foreground">
          {EVO_METRICS.find((m) => m.id === metric)?.label}:{" "}
        </span>
        <span className="font-semibold">{formatEvolutionValue(metric, v ?? 0)}</span>
      </p>
      {(full?.sessoes ?? 0) > 0 && <p className="text-muted-foreground">{full?.sessoes} sessões</p>}
      {(full?.questoes ?? 0) > 0 && (
        <p className="text-muted-foreground">{full?.questoes} questões</p>
      )}
    </div>
  )
}

function QTooltip({ active, payload, label }: ChartTooltipProps) {
  if (!active || !payload?.length) return null
  const p = payload[0]?.payload as { questions?: number; accuracy?: number | null } | undefined
  return (
    <div className="rounded-lg border bg-card p-3 shadow-lg text-xs space-y-0.5">
      <p className="font-semibold mb-1">{label}</p>
      {(p?.questions ?? 0) > 0 && (
        <p>
          <span className="text-muted-foreground">Questões: </span>
          <span className="font-semibold">{p?.questions}</span>
        </p>
      )}
      {p?.accuracy !== null && p?.accuracy !== undefined && (
        <p>
          <span className="text-muted-foreground">Acurácia: </span>
          <span className="font-semibold">{Math.round(p.accuracy)}%</span>
        </p>
      )}
    </div>
  )
}

function PlanTooltip({ active, payload, label }: ChartTooltipProps) {
  if (!active || !payload?.length) return null
  const p = payload[0]?.payload
  return (
    <div className="rounded-lg border bg-card p-3 shadow-lg text-xs space-y-0.5">
      <p className="font-semibold mb-1">{label}</p>
      <p>
        <span className="text-muted-foreground">Realizado: </span>
        <span className="font-semibold">{formatDurationRaw(p?.actualMinutes ?? 0)}</span>
      </p>
      <p>
        <span className="text-muted-foreground">Planejado: </span>
        <span className="font-semibold">{formatDurationRaw(p?.plannedMinutes ?? 0)}</span>
      </p>
      {(p?.actualSessions ?? 0) > 0 && (
        <p className="text-muted-foreground">{p?.actualSessions} sessões</p>
      )}
    </div>
  )
}

// ─── Disciplinas ────────────────────────────────────────────────────────────

type SortKey = "tempo" | "questoes" | "acuracia" | "prioridade" | "erros"

function DisciplinasSection({
  stats,
  totalMinutes: _totalMinutes,
  empty,
}: {
  stats: DisciplineStat[]
  totalMinutes: number
  empty: boolean
}) {
  const [sort, setSort] = useState<SortKey>("tempo")

  const sorted = useMemo(() => {
    const list = [...stats]
    switch (sort) {
      case "tempo":
        return list.sort((a, b) => b.minutes - a.minutes)
      case "questoes":
        return list.sort((a, b) => b.questions - a.questions)
      case "acuracia":
        return list.sort((a, b) => (b.accuracy ?? -1) - (a.accuracy ?? -1))
      case "erros":
        return list.sort((a, b) => b.wrong - a.wrong)
      case "prioridade":
        return list.sort((a, b) => b.attentionScore - a.attentionScore)
      default:
        return list
    }
  }, [stats, sort])

  return (
    <SectionCard
      title="Desempenho por disciplina"
      subtitle="Fórmulas documentadas: acurácia = acertos ÷ questões · tendência = 2ª metade ÷ 1ª metade do período · classificação pelas regras do painel"
      action={
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as SortKey)}
          className="rounded-lg border bg-card px-2.5 py-1.5 text-xs text-foreground print:hidden"
        >
          <option value="tempo">Por tempo</option>
          <option value="questoes">Por questões</option>
          <option value="acuracia">Por acurácia</option>
          <option value="erros">Por erros</option>
          <option value="prioridade">Por prioridade</option>
        </select>
      }
    >
      {empty || sorted.length === 0 ? (
        <EmptyState title="Sem sessões" message="Sem sessões no período — estude uma disciplina para vê-la aqui." />
      ) : (
        <div className="space-y-4">
          {sorted.map((d) => {
            const maxMinutes = Math.max(...sorted.map((x) => x.minutes), 1)
            const pct = (d.minutes / maxMinutes) * 100
            return (
              <div key={d.disciplineId} className="rounded-lg border bg-card p-3 space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold truncate">{d.name}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {d.area ?? "Geral"} · {d.sessions} sessões
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <ClassificationChip classification={d.classification} />
                    {d.daysSinceLastStudy !== null && (
                      <span
                        className={`font-semibold text-[10px] ${d.daysSinceLastStudy > 30 ? "text-rose-600" : "text-muted-foreground"}`}
                      >
                        {d.daysSinceLastStudy === 0 ? "hoje" : `${d.daysSinceLastStudy}d`}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex-1">
                    <ProgressBar pct={pct} height="h-2.5" />
                  </div>
                  <span className="text-xs font-semibold tabular-nums whitespace-nowrap">
                    {formatDurationRaw(d.minutes)}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2 text-[11px]">
                  <div>
                    <p className="text-muted-foreground">Questões</p>
                    <p className="font-semibold">{d.questions}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Acurácia</p>
                    <p className="font-semibold">
                      {d.accuracy === null ? "—" : `${Math.round(d.accuracy)}%`}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Erros</p>
                    <p className="font-semibold text-rose-600">{d.wrong}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Foco</p>
                    <p className="font-semibold">
                      {d.focusAvg === null ? "—" : `${Math.round(d.focusAvg)}%`}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Tendência</p>
                    <p className="font-semibold">
                      <TendenciaChip trend={d.trendDirection} delta={d.accuracyTrend} />
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>
                    {Math.round(d.shareOfTotalMinutes)}% do tempo total · atenção {d.attentionScore}
                    /100
                  </span>
                  <span>
                    páginas {d.pages} · flashcards {d.flashcards}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </SectionCard>
  )
}

function TendenciaChip({
  trend,
  delta,
}: {
  trend: "UP" | "DOWN" | "STABLE"
  delta: number | null
}) {
  if (trend === "UP")
    return (
      <span className="text-emerald-600">▲ {delta === null ? "" : `+${Math.round(delta)}%`}</span>
    )
  if (trend === "DOWN")
    return <span className="text-rose-600">▼ {delta === null ? "" : `${Math.round(delta)}%`}</span>
  return <span className="text-muted-foreground">■ estável</span>
}

// ─── Mapa de erros ──────────────────────────────────────────────────────────

function ErrorMap({
  disciplineStats,
  topicStats,
  empty,
}: {
  disciplineStats: DisciplineStat[]
  topicStats: TopicStat[]
  empty: boolean
}) {
  const byDiscipline = [...disciplineStats]
    .sort((a, b) => b.wrong - a.wrong)
    .filter((d) => d.wrong > 0)
  const byTopic = [...topicStats].sort((a, b) => b.wrong - a.wrong).slice(0, 5)

  if (empty || (byDiscipline.length === 0 && byTopic.length === 0)) {
    return (
      <div>
        <EmptyState title="Sem erros" message="Nenhum erro registrado — sem questões respondidas ou tudo certo por aqui." />
      </div>
    )
  }

  const maxErr = Math.max(...byDiscipline.map((d) => d.wrong), 1)

  return (
    <div className="space-y-4">
      <div>
        <p className="type-label mb-2">Por disciplina</p>
        <div className="space-y-2">
          {byDiscipline.slice(0, 5).map((d) => (
            <div key={d.disciplineId} className="flex items-center gap-2 text-xs">
              <span className="w-40 truncate font-semibold">{d.name}</span>
              <div className="flex-1 h-2 bg-muted/40 rounded-full overflow-hidden">
                <div
                  className="h-full bg-rose-500 rounded-full"
                  style={{ width: `${(d.wrong / maxErr) * 100}%` }}
                />
              </div>
              <span className="font-semibold text-rose-600 w-6 text-right">{d.wrong}</span>
            </div>
          ))}
        </div>
      </div>
      {byTopic.length > 0 && (
        <div>
          <p className="type-label mb-2">Por tópico</p>
          <div className="space-y-1.5">
            {byTopic.map((t) => (
              <div
                key={`${t.disciplineId}-${t.topicName}`}
                className="flex items-center justify-between text-xs border border-border/40 rounded-md px-2.5 py-1.5"
              >
                <span className="truncate font-medium">
                  {t.topicName} <span className="text-muted-foreground">· {t.disciplineName}</span>
                </span>
                <span className="font-semibold text-rose-600">{t.wrong} erros</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Revisões ───────────────────────────────────────────────────────────────

function RevisionSection({
  revision,
}: {
  revision: ReturnType<typeof computeRevisionStatistics> | null
}) {
  return (
    <SectionCard
      title="Revisões (memória)"
      subtitle="Fila do motor de repetição espaçada — atrasadas, de hoje e concluídas nos últimos 30 dias"
      action={<Brain className="h-4 w-4 text-primary" />}
    >
      {/*
        Fase I.6 (M3): três estados distintos. `null` = a consulta não respondeu,
        e aí não mostramos número nenhum — antes esse caso caía no estado vazio e
        dizia "Sem revisões", como se o aluno nunca tivesse revisado.
      */}
      {revision === null && (
        <EmptyState
          title="Não foi possível carregar as revisões"
          message="A consulta ao servidor falhou, então não temos como mostrar sua fila nem as revisões concluídas. Atualize a página em instantes."
        />
      )}
      {revision !== null && revision.totalPending === 0 && revision.completedLast30 === 0 && (
        <EmptyState title="Sem revisões" message="Nenhum item de revisão ainda. Quando o motor de repetição espaçada tiver itens, eles aparecem aqui com a taxa de conclusão." />
      )}
      {revision !== null && (revision.totalPending > 0 || revision.completedLast30 > 0) && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <Metric label="Pendentes" value={revision.totalPending} sub="em fila" />
            <Metric
              label="Atrasadas"
              value={revision.overdue}
              sub="vencidas"
              accent={revision.overdue > 0}
            />
            <Metric label="Para hoje" value={revision.dueToday} sub="vencimento de hoje" />
            <Metric label="Concluídas 30d" value={revision.completedLast30} sub="últimos 30 dias" />
            <Metric
              label="Taxa de conclusão"
              value={
                revision.completionRate === null ? "—" : `${Math.round(revision.completionRate)}%`
              }
              sub="concluídas ÷ (concluídas + pendentes)"
            />
          </div>
          {revision.byDiscipline.length > 0 && (
            <div className="max-h-56 overflow-auto">
              <table className="w-full text-xs min-w-[380px]">
                <thead>
                  <tr className="type-label border-b">
                    <th className="py-2.5 px-3 text-left font-semibold">Disciplina</th>
                    <th className="py-2.5 px-3 text-right font-semibold">Atrasadas</th>
                    <th className="py-2.5 px-3 text-right font-semibold">Próximas</th>
                    <th className="py-2.5 px-3 text-right font-semibold">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {revision.byDiscipline.map((d) => (
                    <tr key={d.disciplineId} className="border-t border-border/40 hover:bg-muted/20 transition-colors">
                      <td className="py-2.5 px-3 font-semibold">{d.name}</td>
                      <td
                        className={`font-semibold py-2.5 px-3 text-right ${d.overdue > 0 ? "text-rose-600" : ""}`}
                      >
                        {d.overdue}
                      </td>
                      <td className="py-2.5 px-3 text-right">{d.dueSoon}</td>
                      <td className="py-2.5 px-3 text-right">{d.total}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </SectionCard>
  )
}

// ─── Eu × Eu ────────────────────────────────────────────────────────────────

const CMP_COLUMNS: { key: CmpKey; label: string }[] = [
  { key: "minutes", label: "Tempo" },
  { key: "sessions", label: "Sessões" },
  { key: "days", label: "Dias" },
  { key: "questions", label: "Questões" },
  { key: "accuracy", label: "Acurácia" },
  { key: "focus", label: "Foco" },
  { key: "pages", label: "Páginas" },
]

function ComparisonsTable({ rows }: { rows: ComparisonRow[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="type-label border-b">
            <th className="py-2.5 px-3 text-left font-semibold">Comparação</th>
            {CMP_COLUMNS.map((c) => (
              <th key={c.key} className="py-2.5 px-3 text-right font-semibold min-w-16">
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-t border-border/40 hover:bg-muted/20 transition-colors">
              <td className="py-2.5 px-3">
                <p className="font-semibold">{r.label}</p>
                <p className="text-[10px] text-muted-foreground">{r.detail}</p>
              </td>
              {CMP_COLUMNS.map((c) => {
                const m = r.metrics[c.key]
                const isPp = c.key === "accuracy" || c.key === "focus"
                return (
                  <td key={c.key} className="py-2.5 px-1.5 text-right">
                    <p className="font-semibold">{metricCmpValue(m, c.key)}</p>
                    <p>
                      <DeltaBadge delta={m?.delta ?? null} suffix={isPp ? "pp" : ""} />
                    </p>
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ─── Horários ───────────────────────────────────────────────────────────────

function BestTimeOfDaySection({ analysis }: { analysis: TimeOfDayAnalysis }) {
  if (!analysis.hasEnoughData || !analysis.overallBest) {
    return (
      <div className="rounded-xl border border-border/60 bg-muted/5 p-4 mb-4">
        <div className="flex items-center gap-2 mb-2">
          <Clock3 aria-hidden className="h-4 w-4 text-muted-foreground" />
          <p className="text-xs font-semibold">Análise de melhor horário</p>
        </div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          {analysis.notEnoughDataMessage ??
            "Ainda não temos dados suficientes para identificar seu melhor horário."}
        </p>
      </div>
    )
  }

  const ob = analysis.overallBest
  const bf = analysis.bestByFocus
  const ba = analysis.bestByAccuracy

  return (
    <div className="space-y-4 mb-4">
      {/* === DESTAQUE: MELHOR HORÁRIO === */}
      <div className="rounded-xl border border-primary/40 bg-primary/5 p-4">
        <div className="flex items-center gap-2 mb-3">
          <Clock3 aria-hidden className="h-4 w-4 text-primary" />
          <p className="text-xs font-semibold text-foreground">Melhor horário para você</p>
        </div>

        <div className="flex flex-wrap items-baseline gap-2 mb-3">
          <p className="text-lg font-semibold text-primary">{ob.label}</p>
          <span className="text-sm tabular-nums text-muted-foreground">{ob.range}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <p className="type-label">
              Foco médio
            </p>
            <p className="text-lg font-semibold text-foreground">
              {ob.focusAvg !== null ? `${Math.round(ob.focusAvg)}%` : "—"}
            </p>
          </div>
          <div>
            <p className="type-label">
              Acerto
            </p>
            <p className="text-lg font-semibold text-foreground">
              {ob.accuracy !== null ? `${Math.round(ob.accuracy)}%` : "—"}
            </p>
          </div>
          <div>
            <p className="type-label">
              Tempo estudado
            </p>
            <p className="text-lg font-semibold text-foreground">
              {formatDurationRaw(ob.totalMinutes)}
            </p>
          </div>
          <div>
            <p className="type-label">
              Questões
            </p>
            <p className="text-lg font-semibold text-foreground">{ob.questions}</p>
          </div>
        </div>

        <p className="text-[11px] text-muted-foreground mt-3 leading-relaxed">
          {analysis.recommendation}
        </p>
      </div>

      {/* === MELHOR FOCO & MELHOR ACERTO === */}
      {(bf || ba) && bf?.period !== ba?.period && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 divide-y sm:divide-y-0 sm:divide-x divide-border/60">
          {bf && (
            <div className="pt-3 sm:pt-0 sm:pr-3">
              <p className="type-label">
                Melhor foco
              </p>
              <p className="text-sm font-semibold text-foreground mt-0.5">{bf.label}</p>
              <p className="text-xs tabular-nums text-muted-foreground">{bf.range}</p>
              <p className="text-lg font-semibold text-primary mt-1">
                {bf.focusAvg !== null ? `${Math.round(bf.focusAvg)}%` : "—"}
              </p>
            </div>
          )}
          {ba && (
            <div className="pt-3 sm:pt-0 sm:pl-3">
              <p className="type-label">
                Melhor acerto
              </p>
              <p className="text-sm font-semibold text-foreground mt-0.5">{ba.label}</p>
              <p className="text-xs tabular-nums text-muted-foreground">{ba.range}</p>
              <p className="text-lg font-semibold text-primary mt-1">
                {ba.accuracy !== null ? `${Math.round(ba.accuracy)}%` : "—"}
              </p>
            </div>
          )}
        </div>
      )}

      {/* === TABELA COMPARATIVA === */}
      <div className="rounded-xl border border-border/60 overflow-hidden">
        <div className="px-3 py-2 border-b border-border/40 bg-muted/5">
          <p className="text-xs font-semibold text-foreground">Desempenho por horário</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="type-label border-b">
                <th className="py-2.5 px-3 text-left font-semibold">Horário</th>
                <th className="py-2.5 px-3 text-left font-semibold">Período</th>
                <th className="py-2.5 px-3 text-right font-semibold">Foco</th>
                <th className="py-2.5 px-3 text-right font-semibold">Acerto</th>
                <th className="py-2.5 px-3 text-right font-semibold">Tempo</th>
                <th className="py-2.5 px-3 text-right font-semibold">Sessões</th>
              </tr>
            </thead>
            <tbody>
              {analysis.buckets.map((b) => {
                const isBest = ob.period === b.period
                return (
                  <tr
                    key={b.period}
                    className={`border-b border-border/20 transition-colors ${isBest ? "bg-primary/5" : "hover:bg-muted/20"}`}
                  >
                    <td className="py-2.5 px-3 tabular-nums font-semibold">{b.range}</td>
                    <td className="py-2.5 px-3">
                      <span className="font-semibold">{b.label}</span>
                      {isBest && (
                        <span className="ml-2 inline-flex items-center text-[11px] font-medium text-primary bg-primary/10 px-1.5 py-0.5 rounded-sm">
                          Melhor
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span
                        className={`font-semibold ${b.focusAvg !== null ? "text-foreground" : "text-muted-foreground"}`}
                      >
                        {b.focusAvg !== null ? `${Math.round(b.focusAvg)}%` : "—"}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span
                        className={`font-semibold ${b.accuracy !== null ? "text-foreground" : "text-muted-foreground"}`}
                      >
                        {b.accuracy !== null ? `${Math.round(b.accuracy)}%` : "—"}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-semibold">
                      {formatDurationRaw(b.totalMinutes)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-semibold">{b.sessions}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* DETALHAMENTO COMPLETO POR FAIXA */}
        <div className="px-3 py-2.5 border-t border-border/40 space-y-1.5">
          {analysis.buckets.map((b) => {
            const isBest = ob.period === b.period
            return (
              <div
                key={b.period}
                className={`text-[10px] ${isBest ? "text-primary font-semibold" : "text-muted-foreground"}`}
              >
                <span className="tabular-nums">{b.range}</span>
                {" — "}
                <span>Tempo: {formatDurationRaw(b.totalMinutes)}</span>
                {" · "}
                <span>Sessões: {b.sessions}</span>
                {" · "}
                <span>Questões: {b.questions}</span>
                {" · "}
                <span>Acertos: {b.correct}</span>
                {" · "}
                <span>Taxa: {b.accuracy !== null ? `${Math.round(b.accuracy)}%` : "—"}</span>
                {" · "}
                <span>Foco: {b.focusAvg !== null ? `${Math.round(b.focusAvg)}%` : "—"}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function HoursSection({ hours, empty }: { hours: HourBucket[]; empty: boolean }) {
  if (empty || hours.every((h) => h.minutes === 0 && h.questions === 0)) {
    return <EmptyState title="Sem sessões" message="Sem sessões no período — os períodos do dia aparecem aqui." />
  }
  const maxMinutes = Math.max(...hours.map((h) => h.minutes), 1)
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {hours.map((h) => (
        <div
          key={h.period}
          className={`rounded-lg border p-3 ${h.best ? "border-emerald-500/40 bg-emerald-500/5" : "border-border/60"}`}
        >
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold">{h.label}</p>
            {/* Fase H: o destaque vem da maior acurácia (≥ 5 questões) OU, sem
                nenhum período com 5 questões, do maior tempo — o texto diz qual. */}
            {h.best && (
              <span className="text-[11px] font-medium text-success">
                {h.questions >= 5 ? "Melhor rendimento" : "Mais tempo de estudo"}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 mt-2">
            <div className="flex-1 h-2 bg-muted/40 rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full"
                style={{ width: `${(h.minutes / maxMinutes) * 100}%` }}
              />
            </div>
            <span className="text-xs font-semibold tabular-nums">{formatDurationRaw(h.minutes)}</span>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-2 text-[11px]">
            <div>
              <p className="text-muted-foreground">Sessões</p>
              <p className="font-semibold">{h.sessions}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Questões</p>
              <p className="font-semibold">{h.questions}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Acurácia</p>
              <p className="font-semibold">
                {h.accuracy === null ? "—" : `${Math.round(h.accuracy)}%`}
              </p>
            </div>
          </div>
          {h.best && h.questions >= 5 && (
            <p className="text-[10px] text-emerald-600 mt-1.5">
              Melhor desempenho registrado (maior acurácia com ≥ 5 questões) — considere fixar a
              prática nesse horário.
            </p>
          )}
          {h.best && h.questions < 5 && (
            <p className="text-[10px] text-muted-foreground mt-1.5">
              Período com mais tempo de estudo. Nenhum período tem 5 ou mais questões para comparar
              acurácia.
            </p>
          )}
        </div>
      ))}
    </div>
  )
}

// ─── Relatório ──────────────────────────────────────────────────────────────

function ReportTable({
  rows,
}: {
  rows: {
    id: string
    label: string
    current: string
    previous: string
    deltaLabel: string
    positive: boolean
  }[]
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="type-label border-b">
            <th className="py-2.5 px-3 text-left font-semibold">Métrica</th>
            <th className="py-2.5 px-3 text-right font-semibold">Atual</th>
            <th className="py-2.5 px-3 text-right font-semibold">Anterior</th>
            <th className="py-2.5 px-3 text-right font-semibold">Δ</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-t border-border/40 hover:bg-muted/20 transition-colors">
              <td className="py-2.5 px-3 font-semibold">{r.label}</td>
              <td className="py-2.5 px-3 text-right font-semibold">{r.current}</td>
              <td className="py-2.5 px-3 text-right text-muted-foreground">{r.previous}</td>
              <td
                className={`py-2.5 px-3 text-right font-semibold ${r.positive ? "text-emerald-600" : "text-rose-600"}`}
              >
                {r.deltaLabel}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
